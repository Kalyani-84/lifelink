import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class StockManagementPage extends StatefulWidget {
  const StockManagementPage({super.key});

  @override
  State<StockManagementPage> createState() => _StockManagementPageState();
}

class _StockManagementPageState extends State<StockManagementPage> {
  final supabase = Supabase.instance.client;

  List<Map<String, dynamic>> stockList = [];
  bool loading = true;

  final bloodTypes = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

  @override
  void initState() {
    super.initState();
    fetchStock();
  }

  Future<void> fetchStock() async {
    try {
      final response = await supabase
          .from('stock')
          .select('*')
          .order('timestamp', ascending: false);

      debugPrint('👉 Stock Response: $response');

      setState(() {
        stockList = List<Map<String, dynamic>>.from(response);
      });
    } catch (e) {
      debugPrint('❗ Error fetching stock: $e');
      showErrorSnackbar('Error fetching stock');
    } finally {
      setState(() {
        loading = false;
      });
    }
  }

  Future<void> addOrUpdateStock({
    String? id,
    required String bloodType,
    required int units,
  }) async {
    try {
      if (id == null) {
        await supabase.from('stock').insert({
          'bank_id': supabase.auth.currentUser?.id as Object,
          'blood_type': bloodType,
          'units': units,
          'timestamp': DateTime.now().toIso8601String(),
        });
        showSuccessSnackbar('Stock added');
      } else {
        await supabase.from('stock').update({
          'units': units,
          'timestamp': DateTime.now().toIso8601String(),
        }).eq('id', id);
        showSuccessSnackbar('Stock updated');
      }
      fetchStock();
    } catch (e) {
      debugPrint('❗ Error saving stock: $e');
      showErrorSnackbar('Error saving stock');
    }
  }

  Future<void> deleteStock(String id) async {
    try {
      await supabase.from('stock').delete().eq('id', id);
      showSuccessSnackbar('Stock deleted');
      fetchStock();
    } catch (e) {
      debugPrint('❗ Error deleting stock: $e');
      showErrorSnackbar('Error deleting stock');
    }
  }

  void showStockDialog({Map<String, dynamic>? stock}) {
    final TextEditingController unitController = TextEditingController(
      text: stock != null ? stock['units'].toString() : '',
    );
    String selectedType = stock?['blood_type'] ?? bloodTypes.first;

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFFFDF4F4),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        title: Text(
          stock != null ? 'Update Stock' : 'Add Stock',
          style: const TextStyle(
            color: Color(0xFF8B0000),
            fontWeight: FontWeight.bold,
          ),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            DropdownButtonFormField<String>(
              value: selectedType,
              items: bloodTypes
                  .map(
                    (type) => DropdownMenuItem(
                      value: type,
                      child: Text(type),
                    ),
                  )
                  .toList(),
              onChanged: (value) {
                if (value != null) selectedType = value;
              },
              decoration: const InputDecoration(labelText: 'Blood Type'),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: unitController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Units'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text(
              'Cancel',
              style: TextStyle(color: Colors.black),
            ),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF8B0000),
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
            onPressed: () {
              final units = int.tryParse(unitController.text);
              if (units != null) {
                addOrUpdateStock(
                  id: stock?['id'],
                  bloodType: selectedType,
                  units: units,
                );
                Navigator.pop(context);
              }
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  void showSuccessSnackbar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: const Color(0xFF8B0000),
        content: Text(message, style: const TextStyle(color: Colors.white)),
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.all(12),
      ),
    );
  }

  void showErrorSnackbar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: const Color(0xFF8B0000),
        content: Text(message, style: const TextStyle(color: Colors.white)),
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.all(12),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFDF4F4),
      appBar: AppBar(
        title: const Text(
          'Stock Management',
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
        ),
        elevation: 0,
        backgroundColor: const Color(0xFFFDF4F4),
        foregroundColor: const Color(0xFF8B0000),
        actions: [
          IconButton(icon: const Icon(Icons.refresh), onPressed: fetchStock),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: const Color(0xFF8B0000),
        onPressed: () => showStockDialog(),
        child: const Icon(Icons.add, color: Colors.white),
      ),
      body: loading
          ? const Center(
              child: CircularProgressIndicator(color: Color(0xFF8B0000)),
            )
          : stockList.isEmpty
              ? const Center(
                  child: Text(
                    'No stock available.',
                    style: TextStyle(fontSize: 14, color: Colors.grey),
                  ),
                )
              : ListView.builder(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  itemCount: stockList.length,
                  itemBuilder: (context, index) {
                    final stock = stockList[index];
                    return Container(
                      margin: const EdgeInsets.only(bottom: 8),
                      child: Material(
                        color: Colors.red.shade100,
                        elevation: 2,
                        shadowColor: Colors.redAccent.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(12),
                        child: ListTile(
                          contentPadding: const EdgeInsets.symmetric(
                              horizontal: 16, vertical: 10),
                          leading: CircleAvatar(
                            radius: 24,
                            backgroundColor: const Color(0xFF8B0000),
                            child: Text(
                              stock['blood_type'],
                              style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 14,
                              ),
                            ),
                          ),
                          title: Text(
                            'Blood Type: ${stock['blood_type']}',
                            style: const TextStyle(
                              fontWeight: FontWeight.w600,
                              fontSize: 16,
                            ),
                          ),
                          subtitle: Padding(
                            padding: const EdgeInsets.only(top: 4),
                            child: Text(
                              'Available Units: ${stock['units']}',
                              style: const TextStyle(
                                fontSize: 14,
                                color: Colors.black87,
                              ),
                            ),
                          ),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(
                                icon: const Icon(Icons.edit,
                                    color: Color(0xFF8B0000)),
                                onPressed: () => showStockDialog(stock: stock),
                              ),
                              IconButton(
                                icon: const Icon(Icons.delete,
                                    color: Color(0xFF8B0000)),
                                onPressed: () =>
                                    deleteStock(stock['id'].toString()),
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
    );
  }
}
