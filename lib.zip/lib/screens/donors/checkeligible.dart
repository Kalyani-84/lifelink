import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../bloodbank/donor_page.dart';
import 'donorform.dart';

class DonorRequestPage extends StatefulWidget {
  const DonorRequestPage({Key? key}) : super(key: key);

  @override
  State<DonorRequestPage> createState() => _DonorRequestPageState();
}

class _DonorRequestPageState extends State<DonorRequestPage> {
  final supabase = Supabase.instance.client;
  bool loading = true;
  List<Map<String, dynamic>> requests = [];

  @override
  void initState() {
    super.initState();
    fetchRequests();
  }

  Future<void> fetchRequests() async {
    setState(() => loading = true);
    final user = supabase.auth.currentUser;

    if (user == null) {
      setState(() {
        requests = [];
        loading = false;
      });
      return;
    }

    try {
      final data = await supabase
          .from('request_to_donor')
          .select('*, bloodbank(name, location)')
          .eq('donor_id', user.id)
          .eq('request_status', 'pending') // ✅ only pending requests
          .order('request_sent_at', ascending: false);

      setState(() {
        requests = List<Map<String, dynamic>>.from(data ?? []);
        loading = false;
      });
    } catch (e) {
      setState(() {
        loading = false;
      });
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Failed to fetch requests: $e')));
    }
  }

  Future<void> updateRequestStatus(
    String requestId,
    String status, {
    DateTime? donationDate,
    String? rejectionReason,
  }) async {
    try {
      final updates = <String, dynamic>{'request_status': status};
      if (status == 'accepted' && donationDate != null) {
        updates['accepted_donate_at'] = donationDate.toUtc().toIso8601String();
        updates['rejection_reason'] = null;
      } else if (status == 'rejected' && rejectionReason != null) {
        updates['rejection_reason'] = rejectionReason;
        updates['accepted_donate_at'] = null;
      }

      await supabase
          .from('request_to_donor')
          .update(updates)
          .eq('id', requestId);

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Request marked as ${status.toUpperCase()}')),
      );
      await fetchRequests();
    } catch (e) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Failed to update request: $e')));
    }
  }

  void showAcceptDialog(String requestId) {
    DateTime selectedDate = DateTime.now();

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Enter donation date & time'),
          content: SizedBox(
            height: 150,
            child: Column(
              children: [
                TextButton(
                  child: const Text('Select Date & Time'),
                  onPressed: () async {
                    final date = await showDatePicker(
                      context: context,
                      initialDate: selectedDate,
                      firstDate: DateTime.now(),
                      lastDate: DateTime.now().add(const Duration(days: 365)),
                    );
                    if (date != null) {
                      final time = await showTimePicker(
                        context: context,
                        initialTime: TimeOfDay.fromDateTime(selectedDate),
                      );
                      if (time != null) {
                        selectedDate = DateTime(
                          date.year,
                          date.month,
                          date.day,
                          time.hour,
                          time.minute,
                        );
                        setState(() {});
                      }
                    }
                  },
                ),
                Text('Selected: ${selectedDate.toLocal()}'.split('.')[0]),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
                updateRequestStatus(
                  requestId,
                  'accepted',
                  donationDate: selectedDate,
                );
              },
              child: const Text('Confirm'),
            ),
          ],
        );
      },
    );
  }

  void showRejectDialog(String requestId) {
    final TextEditingController reasonController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Enter rejection reason'),
          content: TextField(
            controller: reasonController,
            decoration: const InputDecoration(hintText: 'Reason for rejection'),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                final reason = reasonController.text.trim();
                if (reason.isNotEmpty) {
                  Navigator.pop(context);
                  updateRequestStatus(
                    requestId,
                    'rejected',
                    rejectionReason: reason,
                  );
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Please enter a rejection reason'),
                    ),
                  );
                }
              },
              child: const Text('Confirm'),
            ),
          ],
        );
      },
    );
  }

  Widget requestActionButtons(Map<String, dynamic> req) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        TextButton(
          onPressed: () => showAcceptDialog(req['id']),
          child: const Text('✅ Accept'),
        ),
        TextButton(
          onPressed: () => showRejectDialog(req['id']),
          child: const Text('❌ Reject'),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('My Blood Requests'),
        backgroundColor: Colors.redAccent,
        actions: [
          IconButton(
            icon: const Icon(Icons.history),
            tooltip: 'View Request History',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const DonorRequestHistoryPage(),
                ),
              );
            },
          ),
        ],
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : requests.isEmpty
              ? const Center(child: Text('No pending requests.'))
              : ListView.builder(
                  itemCount: requests.length,
                  itemBuilder: (context, index) {
                    final req = requests[index];
                    final bloodbank = req['bloodbank'] ?? {};

                    return Card(
                      margin: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 6,
                      ),
                      child: ListTile(
                        title: Text('From: ${bloodbank['name'] ?? 'Unknown'}'),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('📍 ${bloodbank['location'] ?? 'Unknown'}'),
                            requestActionButtons(req),
                          ],
                        ),
                      ),
                    );
                  },
                ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const DonorFormPage()),
          );
        },
        backgroundColor: Colors.redAccent,
        child: const Icon(Icons.add),
        tooltip: 'Open Donor Eligibility Form',
      ),
    );
  }
}
