import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';

class MyRequestsPage extends StatelessWidget {
  MyRequestsPage({super.key});

  final supabase = Supabase.instance.client;

  Future<List<Map<String, dynamic>>> fetchMyRequests() async {
    final userId = supabase.auth.currentUser?.id;
    if (userId == null) return [];

    // Select from patient_requests and join bloodbank_stock info for each request
    final response = await supabase.from('patient_requests').select('''
          *,
          bloodbank: bloodbank_stock (
            name,
            contact
          )
          ''').eq('patient_id', userId).order('created_at', ascending: false);

    return List<Map<String, dynamic>>.from(response);
  }

  void _callContact(String? contact) async {
    if (contact == null || contact.isEmpty) return;
    final uri = Uri.parse('tel:$contact');
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    }
  }

  @override
  Widget build(BuildContext context) {
    final dateFormat = DateFormat('dd MMM yyyy, hh:mm a');

    return Scaffold(
      appBar: AppBar(title: const Text("My Blood Requests")),
      body: FutureBuilder<List<Map<String, dynamic>>>(
        future: fetchMyRequests(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text("No requests made yet."));
          }

          final requests = snapshot.data!;
          return ListView.builder(
            itemCount: requests.length,
            itemBuilder: (context, index) {
              final req = requests[index];
              final bloodbank = req['bloodbank'] ?? {};
              final bloodbankName = bloodbank['name'] ?? 'Unknown Blood Bank';
              final contact = bloodbank['contact']?.toString() ?? '';
              final createdAt = req['created_at'] != null
                  ? DateTime.parse(req['created_at'])
                  : null;
              final formattedTime =
                  createdAt != null ? dateFormat.format(createdAt) : 'N/A';

              return Card(
                margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                elevation: 3,
                child: ListTile(
                  title: Text(
                    bloodbankName,
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(height: 4),
                      Text("Requested at: $formattedTime"),
                      const SizedBox(height: 4),
                      Text("Blood Type: ${req['blood_type']}"),
                      const SizedBox(height: 4),
                      Text("Units: ${req['requested_units']}"),
                    ],
                  ),
                  trailing: IconButton(
                    icon: const Icon(Icons.phone, color: Colors.redAccent),
                    tooltip: 'Call Blood Bank',
                    onPressed: () => _callContact(contact),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
