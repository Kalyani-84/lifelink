import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:supabase_flutter/supabase_flutter.dart';

final supabase = Supabase.instance.client;

class DonorFormPage extends StatefulWidget {
  const DonorFormPage({super.key});

  @override
  State<DonorFormPage> createState() => _DonorFormPageState();
}

class _DonorFormPageState extends State<DonorFormPage> {
  final _formKey = GlobalKey<FormState>();
  final Map<String, dynamic> _formData = {
    'name': '',
    'age': '',
    'gender': '',
    'weight': '',
    'blood_group': '',
    'location': '',
    'medical_history': '',
  };

  String? _resultMessage;
  bool? _eligible;
  bool _loading = false;

  Future<bool> submitDonorData(Map<String, dynamic> donorData) async {
    final response = await http.post(
      Uri.parse('https://lifelink-ml-api.onrender.com/predict'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode(donorData),
    );

    if (response.statusCode != 200) {
      throw Exception('Failed to get prediction');
    }

    final json = jsonDecode(response.body);
    final eligible = json['eligible'] == true;

    final user = supabase.auth.currentUser;
    if (user == null) throw Exception("User not authenticated");

    await supabase.from('donor_predictions').insert({
      ...donorData,
      'eligible': eligible,
      'user_id': user.id,
      'created_at': DateTime.now().toIso8601String(),
    });

    return eligible;
  }

  void _submit() async {
    if (!_formKey.currentState!.validate()) return;
    _formKey.currentState!.save();

    setState(() {
      _loading = true;
      _resultMessage = null;
    });

    try {
      final eligible = await submitDonorData({
        'name': _formData['name'],
        'age': int.parse(_formData['age']),
        'gender': _formData['gender'],
        'weight': double.parse(_formData['weight']),
        'blood_group': _formData['blood_group'],
        'location': _formData['location'],
        'medical_history': _formData['medical_history'],
      });

      setState(() {
        _eligible = eligible;
      });
    } catch (e) {
      setState(() {
        _resultMessage = 'Error: $e';
      });
    } finally {
      setState(() => _loading = false);
    }
  }

  InputDecoration _inputDecoration(String label) {
    return InputDecoration(
      labelText: label,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
    );
  }

  Widget _buildForm() {
    return Form(
      key: _formKey,
      child: ListView(
        physics: const BouncingScrollPhysics(),
        children: [
          TextFormField(
            decoration: _inputDecoration('Name'),
            onSaved: (v) => _formData['name'] = v ?? '',
            validator: (v) => v!.trim().isEmpty ? 'Required' : null,
          ),
          const SizedBox(height: 12),
          TextFormField(
            decoration: _inputDecoration('Age'),
            keyboardType: TextInputType.number,
            onSaved: (v) => _formData['age'] = v ?? '',
            validator: (v) => v!.trim().isEmpty ? 'Required' : null,
          ),
          const SizedBox(height: 12),
          TextFormField(
            decoration: _inputDecoration('Gender'),
            onSaved: (v) => _formData['gender'] = v ?? '',
            validator: (v) => v!.trim().isEmpty ? 'Required' : null,
          ),
          const SizedBox(height: 12),
          TextFormField(
            decoration: _inputDecoration('Weight'),
            keyboardType: TextInputType.number,
            onSaved: (v) => _formData['weight'] = v ?? '',
            validator: (v) => v!.trim().isEmpty ? 'Required' : null,
          ),
          const SizedBox(height: 12),
          TextFormField(
            decoration: _inputDecoration('Blood Group'),
            onSaved: (v) => _formData['blood_group'] = v ?? '',
            validator: (v) => v!.trim().isEmpty ? 'Required' : null,
          ),
          const SizedBox(height: 12),
          TextFormField(
            decoration: _inputDecoration('Location'),
            onSaved: (v) => _formData['location'] = v ?? '',
            validator: (v) => v!.trim().isEmpty ? 'Required' : null,
          ),
          const SizedBox(height: 12),
          TextFormField(
            decoration: _inputDecoration('Medical History (optional)'),
            onSaved: (v) => _formData['medical_history'] = v ?? '',
            maxLines: 3,
          ),
          const SizedBox(height: 24),
          SizedBox(
            height: 48,
            child: ElevatedButton(
              onPressed: _submit,
              child: _loading
                  ? const CircularProgressIndicator(color: Colors.white)
                  : const Text('Check Eligibility',
                      style: TextStyle(fontSize: 16)),
            ),
          ),
          if (_resultMessage != null) ...[
            const SizedBox(height: 16),
            Text(
              _resultMessage!,
              style: const TextStyle(
                  color: Colors.red, fontWeight: FontWeight.w600),
              textAlign: TextAlign.center,
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildResult() {
    final isEligible = _eligible == true;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            isEligible ? Icons.check_circle_outline : Icons.cancel_outlined,
            color: isEligible ? Colors.green : Colors.red,
            size: 96,
          ),
          const SizedBox(height: 20),
          Text(
            isEligible
                ? '✅ You are eligible to donate blood!'
                : '❌ You are not eligible to donate blood.',
            style: TextStyle(
              color: isEligible ? Colors.green[700] : Colors.red[700],
              fontSize: 22,
              fontWeight: FontWeight.bold,
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 36),
          ElevatedButton(
            onPressed: () => setState(() => _eligible = null),
            child: const Text('Check Again'),
            style: ElevatedButton.styleFrom(
              minimumSize: const Size(double.infinity, 48),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Donor Eligibility Check')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : (_eligible == null ? _buildForm() : _buildResult()),
      ),
    );
  }
}
