import 'dart:async';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'requestpage.dart';

class PatientPage extends StatefulWidget {
  const PatientPage({super.key});

  @override
  State<PatientPage> createState() => _PatientPageState();
}

class _PatientPageState extends State<PatientPage> {
  final supabase = Supabase.instance.client;
  List<dynamic> stockData = [];
  List<dynamic> filteredData = [];
  String searchQuery = "";
  Timer? _refreshTimer;

  @override
  void initState() {
    super.initState();
    fetchStockData();
    _refreshTimer = Timer.periodic(const Duration(seconds: 10), (_) {
      setState(() {}); // force rebuild if needed
    });
  }

  @override
  void dispose() {
    _refreshTimer?.cancel();
    super.dispose();
  }

  Future<void> fetchStockData() async {
    try {
      final data = await supabase.from('bloodbank_stock').select();
      setState(() {
        stockData = data;
        filteredData = stockData;
      });
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Error: $e')));
    }
  }

  void filterSearch(String query) {
    setState(() {
      searchQuery = query;
      filteredData = stockData.where((item) {
        final bloodType = item['blood_type']?.toString().toLowerCase() ?? '';
        return bloodType.contains(query.toLowerCase());
      }).toList();
    });
  }

  Future<void> showRequestDialog(Map item) async {
    final unitsController = TextEditingController();
    String selectedUrgency = 'low';

    print('Debug - Item data: $item'); // Debug: print item map

    await showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              title: const Text("Request Blood"),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text("From: ${item['name']}"),
                  TextField(
                    controller: unitsController,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(labelText: "Units"),
                  ),
                  const SizedBox(height: 10),
                  DropdownButtonFormField<String>(
                    value: selectedUrgency,
                    onChanged: (value) {
                      if (value != null) {
                        setState(() => selectedUrgency = value);
                      }
                    },
                    items: ['low', 'medium', 'high'].map((level) {
                      return DropdownMenuItem(
                        value: level,
                        child: Text(
                          level[0].toUpperCase() + level.substring(1),
                        ),
                      );
                    }).toList(),
                    decoration: const InputDecoration(labelText: "Urgency"),
                  ),
                ],
              ),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.pop(context);
                    unitsController.dispose();
                  },
                  child: const Text("Cancel"),
                ),
                ElevatedButton(
                  onPressed: () async {
                    final units =
                        int.tryParse(unitsController.text.trim()) ?? 0;
                    final userId = supabase.auth.currentUser?.id;

                    print('Debug - UserId: $userId');
                    print('Debug - Units: $units');
                    print('Debug - Bloodbank ID: ${item['bbid']}');

                    if (userId == null) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text("User not logged in")),
                      );
                      return;
                    }

                    if (units <= 0) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text("Please enter a valid number of units"),
                        ),
                      );
                      return;
                    }

                    if (item['bbid'] == null) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text("Blood bank ID is missing"),
                        ),
                      );
                      return;
                    }

                    try {
                      await supabase.from('patient_requests').insert({
                        'patient_id': userId,
                        'bloodbank_id': item['bbid'],
                        'blood_type': item['blood_type'],
                        'requested_units': units,
                        'urgency': selectedUrgency,
                      });

                      if (!mounted) return;
                      Navigator.pop(context);
                      unitsController.dispose();
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text("Request sent successfully!"),
                        ),
                      );
                    } catch (e) {
                      if (!mounted) return;
                      ScaffoldMessenger.of(
                        context,
                      ).showSnackBar(SnackBar(content: Text('Failed: $e')));
                    }
                  },
                  child: const Text("Send Request"),
                ),
              ],
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Patient Page"),
        actions: [
          IconButton(
            icon: const Icon(Icons.history),
            tooltip: "My Requests",
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => MyRequestsPage()),
              );
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(10),
            child: TextField(
              onChanged: filterSearch,
              decoration: const InputDecoration(
                labelText: 'Search by Blood Type',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.search),
              ),
            ),
          ),
          Expanded(
            child: filteredData.isEmpty
                ? const Center(child: Text("No stock data found"))
                : ListView.builder(
                    itemCount: filteredData.length,
                    itemBuilder: (context, index) {
                      final item = filteredData[index];
                      return Card(
                        margin: const EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 5,
                        ),
                        child: ListTile(
                          title: Text(item['name'] ?? 'Unknown'),
                          subtitle: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text("Location: ${item['location']}"),
                              Text("Blood Type: ${item['blood_type']}"),
                              Text("Units: ${item['units']}"),
                            ],
                          ),
                          trailing: ElevatedButton(
                            onPressed: () => showRequestDialog(item),
                            child: const Text("Request"),
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
